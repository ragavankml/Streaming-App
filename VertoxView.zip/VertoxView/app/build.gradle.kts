plugins {
    id("com.android.application")
    id("com.google.gms.google-services")
}

android {
    namespace = "com.example.vertoxview"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.vertoxview"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
}

dependencies {

    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.10.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")

    // Load image from Data Base
    implementation ("com.squareup.picasso:picasso:2.71828")

    //FireBase Auth
    implementation(platform("com.google.firebase:firebase-bom:32.7.0"))
    implementation("com.google.firebase:firebase-auth")

    //FireBase Data Base
    implementation("com.google.firebase:firebase-database:20.3.0")
    implementation("com.google.firebase:firebase-firestore:24.10.0")
    implementation ("com.firebaseui:firebase-ui-database:8.0.2")

    //Welcome Animation
    implementation ("nl.dionsegijn:konfetti-xml:2.0.4")

    //Exoplayer
    implementation ("com.google.android.exoplayer:exoplayer:2.19.1")
    implementation ("com.google.android.exoplayer:exoplayer-core:2.19.1")
    implementation ("com.google.android.exoplayer:exoplayer-dash:2.19.1")
    implementation ("com.google.android.exoplayer:exoplayer-ui:2.19.1")

    //Glide
    implementation ("com.github.bumptech.glide:glide:4.12.0") // Use the latest version available
    annotationProcessor ("com.github.bumptech.glide:compiler:4.12.0")

    //Paletten
    implementation ("androidx.palette:palette:1.0.0")

    //Shemmer effect
    implementation ("com.facebook.shimmer:shimmer:0.5.0")



}