package com.example.vertoxview.fragments;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;

import androidx.appcompat.widget.AppCompatButton;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import android.view.animation.BounceInterpolator;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.vertoxview.R;
import com.example.vertoxview.activity.LoginUserNameActivity;
import com.example.vertoxview.activity.SettingsActivity;
import com.example.vertoxview.model.UserModel;
import com.example.vertoxview.utils.FirebaseUtil;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

public class ProfileFragment extends Fragment {


    private float originalScaleX;
    private float originalScaleY;
    private boolean isAnimationInProgress = false;
    TextView userMobileNumber,username;
    LinearLayout settingBtn,edit_name;
    AppCompatButton premium_btn;
    String normal_mobile_number;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        final TextView gradientText = view.findViewById(R.id.gradientText);
        userMobileNumber = view.findViewById(R.id.user_mobile_number);

        username = view.findViewById(R.id.user_name_text);
        settingBtn = view.findViewById(R.id.setting_btn);
        premium_btn = view.findViewById(R.id.upgrad_btn);
        edit_name = view.findViewById(R.id.edit_btn);

        //Setting Btn Click
        settingBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the SettingsActivity
                Intent intent = new Intent(requireContext(), SettingsActivity.class);
                startActivity(intent);
            }
        });


        // Get the current user's data from Firebase
        DatabaseReference currentUserRef = FirebaseUtil.currentUserDetails();
        currentUserRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    UserModel userModel = dataSnapshot.getValue(UserModel.class);

                    // Set the user's mobile number to the TextView
                    if (userModel != null) {
                        String userName = userModel.getUsername();
                        String mobileNumber = userModel.getPhone();
                        normal_mobile_number=mobileNumber;
                        mobileNumber = "+91 "+(mobileNumber.substring(3));
                        userMobileNumber.setText(mobileNumber);
                        username.setText(userName);

                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle error
            }
        });

        //Edit Btn Click
        edit_name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(requireContext(), LoginUserNameActivity.class);
                intent.putExtra("phone",normal_mobile_number);
                startActivity(intent);
            }
        });

        // Gradient Text
        gradientText.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                // Remove the listener to avoid redundant calls
                gradientText.getViewTreeObserver().removeOnGlobalLayoutListener(this);

                // Set up the gradient color using color resources
                int colorGold_c = ContextCompat.getColor(requireContext(), R.color.gold_c);
                int colorGold_e = ContextCompat.getColor(requireContext(), R.color.gold_e);
                // Set up the gradient color
                int[] colors = {colorGold_e, colorGold_c,colorGold_e}; // Green to Blue gradient

                // Calculate the center of the TextView
                float centerX = gradientText.getWidth() / 2f;
                float centerY = gradientText.getHeight() / 2f;

                // Calculate the radius from the center to the corners
                float radius = (float) Math.hypot(centerX, centerY);

                // Create a LinearGradient from the center to the corners
                Shader shader = new LinearGradient(centerX, centerY, 0, 0,
                        colors, null, Shader.TileMode.CLAMP);

                // Apply the gradient to the TextView's paint
                gradientText.getPaint().setShader(shader);
            }
        });

        //Premium Button Animation Touch
        premium_btn.setOnTouchListener(new View.OnTouchListener() {
            @SuppressLint("ClickableViewAccessibility")
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                // Check the action type (down, up, etc.)
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if (!isAnimationInProgress) {
                            // Save the original scale values
                            originalScaleX = premium_btn.getScaleX();
                            originalScaleY = premium_btn.getScaleY();

                            // Call the function to perform size reduction animation
                            performSizeReductionAnimation();
                        }
                        break;
                }

                // Return false to allow other touch events to be handled
                return !isAnimationInProgress;
            }
        });


        return view;
    }

    //performSizeReductionAnimation
    private void performSizeReductionAnimation() {
        isAnimationInProgress = true;

        // Create ObjectAnimator to smoothly animate scaleX and scaleY
        ObjectAnimator scaleDownX = ObjectAnimator.ofFloat(premium_btn, "scaleX", 0.9f);
        ObjectAnimator scaleDownY = ObjectAnimator.ofFloat(premium_btn, "scaleY", 0.9f);

        // Set the duration of the animation
        int duration = 100;
        scaleDownX.setDuration(duration);
        scaleDownY.setDuration(duration);

        // Set up the AnimatorListener to trigger bounce-back animation when size reduction is complete
        scaleDownX.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                performBounceAnimation();
            }
        });

        // Start the animation
        scaleDownX.start();
        scaleDownY.start();
    }

    //BounceAnimation
    private void performBounceAnimation() {
        // Create ObjectAnimator to smoothly animate scaleX and scaleY back to original values with a bounce effect
        ObjectAnimator bounceBackX = ObjectAnimator.ofFloat(premium_btn, "scaleX", originalScaleX);
        ObjectAnimator bounceBackY = ObjectAnimator.ofFloat(premium_btn, "scaleY", originalScaleY);

        // Set the duration of the animation
        int duration = 400;
        bounceBackX.setDuration(duration);
        bounceBackY.setDuration(duration);

        // Set a bounce interpolator for a realistic bouncing effect
        bounceBackX.setInterpolator(new BounceInterpolator());
        bounceBackY.setInterpolator(new BounceInterpolator());

        // Set up the AnimatorListener to reset the flag when bounce-back animation is complete
        bounceBackX.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                isAnimationInProgress = false;
            }
        });

        // Start the animation
        bounceBackX.start();
        bounceBackY.start();
    }
}
