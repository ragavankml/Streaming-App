package com.example.vertoxview.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.vertoxview.R;
import com.example.vertoxview.model.EpisodeModel;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

public class EpisodeAdapter extends FirebaseRecyclerAdapter<EpisodeModel,EpisodeAdapter.myviewholder> {

    private OnItemClickListener itemClickListener;
    public EpisodeAdapter(@NonNull FirebaseRecyclerOptions<EpisodeModel> options) {
        super(options);
    }

    public interface OnItemClickListener {
        void onItemClick(EpisodeModel episodeModel);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.itemClickListener = listener;
    }

    @Override
    protected void onBindViewHolder(@NonNull myviewholder holder, int position, @NonNull EpisodeModel model) {

        holder.name.setText(model.getName());
        holder.chname.setText(model.getChname());
        holder.url.setText(model.getUrl());
        // Set click listener
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (itemClickListener != null) {
                    itemClickListener.onItemClick(model);
                }
            }
        });
    }

    @NonNull
    @Override
    public myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.episodes_item,parent,false);
        return new myviewholder(view);
    }

    class myviewholder extends RecyclerView.ViewHolder
    {
        TextView name,chname,url;
        public myviewholder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.nametext);
            chname = itemView.findViewById(R.id.destext);
            url = itemView.findViewById(R.id.urlLink);
        }
    }

}
