package com.example.vertoxview.fragments;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.os.Handler;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.BounceInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.VideoView;

import com.example.vertoxview.R;
import com.example.vertoxview.activity.PlayActivity;
import com.example.vertoxview.model.SlideModel;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.firebase.database.DatabaseReference;
import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link BottomSheetFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class BottomSheetFragment extends BottomSheetDialogFragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private float originalScaleX;
    private float originalScaleY;
    private boolean isAnimationInProgress = false;
    LinearLayout watch_now;

    public BottomSheetFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment BottomSheetFragment.
     */
    // TODO: Rename and change types and number of parameters


    ImageView close_bt;
    VideoView videoView;
    ImageView trailer1;
    ImageView coverpage1;
    ImageView nameIm;
    ProgressBar progressBar1;
    ProgressBar progressBar1_buff;
    TextView title_trailer;
    private boolean isBuffering = false;
    private List<SlideModel> mList;
    private DatabaseReference databaseReference;
    // Declare a Handler and a Runnable globally
    private Handler handler = new Handler();
    private Runnable updateProgressBar;

    ImageView trailer2;
    ImageView trailer3;
    private static final String EXTRA_IMAGE_URL = "imageUrl";
    private static final String EXTRA_VIDEO_URL = "videoUrl";
    private static final String EXTRA_NAME_URL = "nameUrl";
    private static final String EXTRA_TITLE = "title";
    private static final String EXTRA_FIRSTEP_URL = "firstEpUrl";
    private static final String EXTRA_FIRSTEP_TITLE = "firstEpTitle";

    public String epurl;
    public String eptitle;

    // Existing code...

    public static BottomSheetFragment newInstance(String imageUrl, String videoUrl, String nameUrl,String title, String firstEpUrl, String firstEpTitle) {
        BottomSheetFragment fragment = new BottomSheetFragment();
        Bundle args = new Bundle();
        args.putString(EXTRA_IMAGE_URL, imageUrl);
        args.putString(EXTRA_VIDEO_URL, videoUrl);
        args.putString(EXTRA_NAME_URL, nameUrl);
        args.putString(EXTRA_TITLE, title);
        args.putString(EXTRA_FIRSTEP_URL, firstEpUrl);
        args.putString(EXTRA_FIRSTEP_TITLE, firstEpTitle);
        fragment.setArguments(args);
        return fragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_bottom_sheet, container, false);
        // Initialize Firebase database reference

        //Close Img_bt Id find
        close_bt = view.findViewById(R.id.close_btn);

        //Video View Id
        videoView = view.findViewById(R.id.videoView);

        //Trailer_play_btn
        trailer1 = view.findViewById(R.id.trailer_1_play);
        coverpage1 = view.findViewById(R.id.cover_baner1);
        progressBar1 = view.findViewById(R.id.progressBar1);
        nameIm = view.findViewById(R.id.nameIm);
        title_trailer = view.findViewById(R.id.title_name);
        progressBar1_buff = view.findViewById(R.id.progressBar_load1);
        watch_now = view.findViewById(R.id.watch_now_btn);


        // Retrieve position from arguments
        String coverUrl = getArguments().getString(EXTRA_IMAGE_URL, String.valueOf(-1));
        // Replace "YOUR_VIDEO_URL" with the actual URL of the video you want to play
        String videoUrl = getArguments().getString(EXTRA_VIDEO_URL, String.valueOf(-1));
        // Replace NameIm
        String nameUrl = getArguments().getString(EXTRA_NAME_URL, String.valueOf(-1));
        //Replace Title
        String title = getArguments().getString(EXTRA_TITLE, String.valueOf(-1));
        //First Ep Url Retrieve
        epurl = getArguments().getString(EXTRA_FIRSTEP_URL, String.valueOf(-1));
        //First Ep Url Retrieve
        eptitle = getArguments().getString(EXTRA_FIRSTEP_TITLE, String.valueOf(-1));

        Picasso.get().load(coverUrl).into(coverpage1);
        Picasso.get().load(nameUrl).into(nameIm);
        title_trailer.setText(title);

        // Set up a click listener for the close button
        close_bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Dismiss the BottomSheet when the close button is clicked
                dismiss();
            }
        });



        // Set the video URI and start playing
        videoView.setVideoURI(Uri.parse(videoUrl));

        // Update progress during playback
        videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                progressBar1.setMax(videoView.getDuration());

                // Use a Handler to update ProgressBar on the main thread
                final android.os.Handler handler = new android.os.Handler();

                // Define a Runnable to update ProgressBar
                final Runnable updateProgressBar = new Runnable() {
                    @Override
                    public void run() {
                        if (videoView != null) {
                            int current = videoView.getCurrentPosition();
                            progressBar1.setProgress(current);
                            handler.postDelayed(this, 500); // Update every half a second (adjust as needed)
                        }
                    }
                };

                // Post the initial update to the main thread using the handler
                handler.post(updateProgressBar);
            }
        });




        videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                progressBar1.setMax(videoView.getDuration());

                // Define a Runnable to update ProgressBar
                updateProgressBar = new Runnable() {
                    @Override
                    public void run() {
                        if (isNetworkAvailable()) {
                            int current = videoView.getCurrentPosition();
                            progressBar1.setProgress(current);
                            handler.postDelayed(this, 100); // Update every 100 milliseconds (adjust as needed)
                        } else {
                            // Video is not playing, or videoView is null (possibly due to loss of internet)
                            // Stop updating the progress bar
                            handler.removeCallbacks(this);
                            videoView.pause();
                            showNoInternetAlertDialog();
                            dismiss();
                        }
                    }
                };


                // Post the initial update to the main thread using the handler
                handler.post(updateProgressBar);

                // Hide the buffering progress bar once the video is prepared
                progressBar1_buff.setVisibility(View.GONE);
            }
        });

        videoView.setOnInfoListener(new MediaPlayer.OnInfoListener() {
            @Override
            public boolean onInfo(MediaPlayer mp, int what, int extra) {
                switch (what) {
                    case MediaPlayer.MEDIA_INFO_BUFFERING_START:
                        // Buffering started, show the progress bar
                        isBuffering = true;
                        progressBar1_buff.setVisibility(View.VISIBLE);
                        break;
                    case MediaPlayer.MEDIA_INFO_BUFFERING_END:
                        // Buffering ended, hide the cover page and progress bar
                        isBuffering = false;
                        progressBar1_buff.setVisibility(View.GONE);
                        break;
                }
                return false;
            }
        });


        // Set up a click listener for the trailer_1btn
        trailer1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (videoView.isPlaying()) {
                    // If the video is playing, pause it
                    videoView.pause();
                    trailer1.setImageResource(R.drawable.icon_play_btn); // Change to play button icon
                } else {
                    // If the video is not playing, start or resume
                    if (videoView.getCurrentPosition() > 0) {
                        // If the video was stopped, resume from the current position
                        videoView.start();
                        trailer1.setImageResource(R.drawable.icon_pass_btn); // Change to pause/stop button icon
                    } else {
                        // If the video was not started yet, start it
                        coverpage1.setVisibility(View.GONE);
                        progressBar1.setVisibility(View.VISIBLE);
                        videoView.start();
                        trailer1.setImageResource(R.drawable.icon_pass_btn); // Change to pause/stop button icon
                    }
                }
            }
        });


        //On trailer 1 complete
        videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mediaPlayer) {
                // Video playback has completed
                videoView.seekTo(0); // Reset the video to the beginning
                coverpage1.setVisibility(View.VISIBLE);
                progressBar1.setVisibility(View.GONE);
                trailer1.setImageResource(R.drawable.icon_play_btn); // Change to play button icon
            }
        });

        //Watch Now OnTouch
        watch_now.setOnTouchListener(new View.OnTouchListener() {
            @SuppressLint("ClickableViewAccessibility")
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                // Check the action type (down, up, etc.)
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if (!isAnimationInProgress) {
                            // Save the original scale values
                            originalScaleX = watch_now.getScaleX();
                            originalScaleY = watch_now.getScaleY();

                            // Call the function to perform size reduction animation
                            performSizeReductionAnimation();
                        }
                        break;
                }

                // Return false to allow other touch events to be handled
                return !isAnimationInProgress;
            }
        });
        //Watch Click
        watch_now.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
                Intent intent = new Intent(requireContext(), PlayActivity.class);
                intent.putExtra("FirtEpUrl",epurl);
                intent.putExtra("FirtEpTitle",eptitle);
                intent.putExtra("Title_Onely",title);
                startActivity(intent);
            }
        });

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        // Set the BottomSheet to initially take up the full screen
        if (getDialog() != null) {
            BottomSheetDialog dialog = (BottomSheetDialog) getDialog();
            FrameLayout bottomSheet = dialog.findViewById(com.google.android.material.R.id.design_bottom_sheet);

            if (bottomSheet != null) {
                BottomSheetBehavior<FrameLayout> behavior = BottomSheetBehavior.from(bottomSheet);
                behavior.setState(BottomSheetBehavior.STATE_EXPANDED);
                behavior.setPeekHeight(getResources().getDisplayMetrics().heightPixels);
            }
        }
    }
    @Override
    public void onDestroyView() {
        super.onDestroyView();

        // Remove callbacks to avoid memory leaks
        handler.removeCallbacks(updateProgressBar);
    }

    private void showNoInternetAlertDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle("No Internet Connection");
        builder.setMessage("Please check your internet connection and try again.");
        builder.setPositiveButton("OK", null);
        builder.show();
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager = (ConnectivityManager)
                requireContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager != null) {
            NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
            return activeNetworkInfo != null && activeNetworkInfo.isConnected();
        }
        return false;
    }

    private void performSizeReductionAnimation() {
        isAnimationInProgress = true;

        // Create ObjectAnimator to smoothly animate scaleX and scaleY
        ObjectAnimator scaleDownX = ObjectAnimator.ofFloat(watch_now, "scaleX", 0.9f);
        ObjectAnimator scaleDownY = ObjectAnimator.ofFloat(watch_now, "scaleY", 0.9f);

        // Set the duration of the animation
        int duration = 100;
        scaleDownX.setDuration(duration);
        scaleDownY.setDuration(duration);

        // Set up the AnimatorListener to trigger bounce-back animation when size reduction is complete
        scaleDownX.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                performBounceAnimation();
            }
        });

        // Start the animation
        scaleDownX.start();
        scaleDownY.start();
    }

    //BounceAnimation
    private void performBounceAnimation() {
        // Create ObjectAnimator to smoothly animate scaleX and scaleY back to original values with a bounce effect
        ObjectAnimator bounceBackX = ObjectAnimator.ofFloat(watch_now, "scaleX", originalScaleX);
        ObjectAnimator bounceBackY = ObjectAnimator.ofFloat(watch_now, "scaleY", originalScaleY);

        // Set the duration of the animation
        int duration = 400;
        bounceBackX.setDuration(duration);
        bounceBackY.setDuration(duration);

        // Set a bounce interpolator for a realistic bouncing effect
        bounceBackX.setInterpolator(new BounceInterpolator());
        bounceBackY.setInterpolator(new BounceInterpolator());

        // Set up the AnimatorListener to reset the flag when bounce-back animation is complete
        bounceBackX.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                isAnimationInProgress = false;
            }
        });

        // Start the animation
        bounceBackX.start();
        bounceBackY.start();
    }
}