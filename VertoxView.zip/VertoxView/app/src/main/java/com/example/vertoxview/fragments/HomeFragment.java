package com.example.vertoxview.fragments;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatButton;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import android.os.Handler;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.BounceInterpolator;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.vertoxview.R;
import com.example.vertoxview.adapter.MostPopularAnimeAdapter;
import com.example.vertoxview.model.MostPopularAnimeModel;
import com.example.vertoxview.model.SlideModel;
import com.example.vertoxview.activity.SliderPagerAdapter;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
public class HomeFragment extends Fragment {

    private float originalScaleX;
    private float originalScaleY;
    private boolean isAnimationInProgress = false;

    // Slide List
    private List<SlideModel> mList;

    //Data Base Reference
    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference();

    //SlidePager
    ViewPager slides;
    ProgressBar progressBar;

    //SlidePager Indicator
    private TabLayout tabLayout;

    //  auto-sliding in milliseconds
    private static final long SLIDE_INTERVAL = 5000;
    private Handler handler = new Handler();
    private Runnable runnable;

    // Slide Explore Button
    AppCompatButton slide_explore;
    private Handler handler_ex_s = new Handler();

    // Declare a boolean flag For Slide Explore
    private boolean isButtonClickable = true;
    // Flag to check if the fragment is still active
    private boolean isFragmentActive = false;
    private RecyclerView RvMostPopularAnime;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the flag to indicate that the fragment is active
        isFragmentActive = true;
        fetchSlidesFromDatabase();
        fetchPopularAnimeFromDatabase();
    }

    // Method to fetch slides from the database
    private void fetchSlidesFromDatabase() {
        DatabaseReference slidesReference = databaseReference.child("slides");

        slidesReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                // Hide the ProgressBar once data is loaded
                progressBar.setVisibility(View.GONE);
                List<SlideModel> fetchedSlides = new ArrayList<>();

                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    String imageUrl = snapshot.child("imageUrl").getValue(String.class);
                    String title = snapshot.child("title").getValue(String.class);
                    String videoUlr = snapshot.child("videoUrl").getValue(String.class);
                    String nameUlr = snapshot.child("imagenameUrl").getValue(String.class);
                    String firstEpUrl = snapshot.child("firstepur").getValue(String.class);
                    String firstEpTitle = snapshot.child("firstepti").getValue(String.class);

                    fetchedSlides.add(new SlideModel(imageUrl, title, videoUlr, nameUlr,firstEpUrl,firstEpTitle));
                }

                if (!isFragmentActive) {
                    // Check if the fragment is still active before updating UI
                    return;
                }

                SliderPagerAdapter adapter = new SliderPagerAdapter(requireContext(), fetchedSlides);
                slides.setAdapter(adapter);

                mList = fetchedSlides;
                slide_explore.setVisibility(View.VISIBLE);

                autoSlideViewPager(adapter.getCount());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                if (isFragmentActive) {
                    // Hide the ProgressBar in case of an error
                    progressBar.setVisibility(View.GONE);
                    // Check if the fragment is still active before showing the error
                    Toast.makeText(getActivity(), "Failed to Connect To Database", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Method to fetch Popular Anime from the database
    private void fetchPopularAnimeFromDatabase() {
        DatabaseReference mostPopularReference = databaseReference.child("mostPopular");
        mostPopularReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                List<MostPopularAnimeModel> lstMovies = new ArrayList<>();

                if (!isFragmentActive) {
                    // Check if the fragment is still active before updating UI
                    return;
                }
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    String movieTitle = snapshot.child("title").getValue(String.class);
                    String posterResource = snapshot.child("thumbnail").getValue(String.class);
                    String trailerResource = snapshot.child("coverPhoto").getValue(String.class);
                    String description = snapshot.child("description").getValue(String.class);
                    String videoUlr = snapshot.child("videoUrl").getValue(String.class);
                    String firstEpUrl = snapshot.child("firstepur").getValue(String.class);
                    String firstEpTitle = snapshot.child("firstepti").getValue(String.class);
                    String nameUlr = snapshot.child("imagenameUrl").getValue(String.class);

                    // Check for null values before adding to the list
                    if (movieTitle != null && posterResource != null && trailerResource != null && description != null) {
                        lstMovies.add(new MostPopularAnimeModel(movieTitle, posterResource, trailerResource, description, videoUlr, firstEpUrl, firstEpTitle, nameUlr));
                    }
                }

                // Update RecyclerView with the fetched data
                // Update RecyclerView with the fetched data
                MostPopularAnimeAdapter animeAdapter = new MostPopularAnimeAdapter(requireContext(), lstMovies, new MostPopularAnimeAdapter.OnItemClickListener() {
                    @Override
                    public void onItemClick(MostPopularAnimeModel anime) {
                        // Handle item click here
                        openBottomSheet(anime);
                    }
                });

                RvMostPopularAnime.setAdapter(animeAdapter);
                RvMostPopularAnime.setLayoutManager(new LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                if (isFragmentActive) {
                    // Check if the fragment is still active before showing the error
                    Toast.makeText(getActivity(), "Failed to Connect To Database", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void openBottomSheet(MostPopularAnimeModel anime) {
        // Extract necessary data from the anime model
        String imageUrl = anime.getCoverPhoto();
        String videoUrl = anime.getVideourl();
        String nameUrl = anime.getNameUrl();
        String title = anime.getTitle();
        String firstEpUrl = anime.getFirst_ep_url();
        String firstEpTitle = anime.getFirst_ep_title();



        // Create and show the BottomSheetFragment
        BottomSheetFragment bottomSheetFragment = BottomSheetFragment.newInstance(imageUrl, videoUrl, nameUrl, title, firstEpUrl, firstEpTitle);
        bottomSheetFragment.show(getFragmentManager(), bottomSheetFragment.getTag());
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        //Find SlidePager Id
        slides = view.findViewById(R.id.slider_pager);
        //Find SlidePager Indicator Id
        tabLayout=view.findViewById(R.id.tab_layout);
        // SetUp With Table
        tabLayout.setupWithViewPager(slides,true);
        // Slide Explore Button
        slide_explore = view.findViewById(R.id.home_slide_explore_button);
        // Most Popular Anime
        RvMostPopularAnime = view.findViewById(R.id.Rv_most_ani);
        // Slide Progress Bar
        progressBar = view.findViewById(R.id.slide_progressbar);
        // Slide Explore Button onClick
        slide_explore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Check if the button is clickable
                if (isButtonClickable) {
                    // Disable the button
                    isButtonClickable = false;

                    // Pass the current slide position to BottomSheetFragment
                    int currentItem = slides.getCurrentItem();
                    SlideModel currentSlide = mList.get(currentItem);
                    String imageUrl = currentSlide.getImage();
                    String videoUrl = currentSlide.getVideo();
                    String nameUrl = currentSlide.getNameIm();
                    String title = currentSlide.getTitle();
                    String firstEpUrl = currentSlide.getFirst_ep_url();
                    String firstEpTitle = currentSlide.getFirst_ep_title();

                    BottomSheetFragment bottomSheetFragment = BottomSheetFragment.newInstance(imageUrl,videoUrl,nameUrl,title,firstEpUrl,firstEpTitle);
                    bottomSheetFragment.show(getFragmentManager(), bottomSheetFragment.getTag());




                    // Delay re-enabling the button by a short duration (e.g., 500 milliseconds)
                    handler_ex_s.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            // Enable the button after the delay
                            isButtonClickable = true;
                        }
                    }, 500);
                }
            }
        });

        //Slide Explore OnTouch
        slide_explore.setOnTouchListener((v, event) -> {
            // Check the action type (down, up, etc.)
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    if (!isAnimationInProgress) {
                        // Save the original scale values
                        originalScaleX = slide_explore.getScaleX();
                        originalScaleY = slide_explore.getScaleY();

                        // Call the function to perform size reduction animation
                        performSizeReductionAnimation();
                    }
                    break;
            }

            // Return false to allow other touch events to be handled
            return !isAnimationInProgress;
        });


        return view;

    }

    //Slide_AutoSlide
    private void autoSlideViewPager(final int count) {
        runnable = new Runnable() {
            public void run() {
                int currentItem = slides.getCurrentItem();
                currentItem = (currentItem + 1) % count;
                slides.setCurrentItem(currentItem);
                handler.postDelayed(this, SLIDE_INTERVAL);
            }
        };
        handler.postDelayed(runnable, SLIDE_INTERVAL);
    }

    //performSizeReductionAnimation
    private void performSizeReductionAnimation() {
        isAnimationInProgress = true;

        // Create ObjectAnimator to smoothly animate scaleX and scaleY
        ObjectAnimator scaleDownX = ObjectAnimator.ofFloat(slide_explore, "scaleX", 0.9f);
        ObjectAnimator scaleDownY = ObjectAnimator.ofFloat(slide_explore, "scaleY", 0.9f);

        // Set the duration of the animation
        int duration = 100;
        scaleDownX.setDuration(duration);
        scaleDownY.setDuration(duration);

        // Set up the AnimatorListener to trigger bounce-back animation when size reduction is complete
        scaleDownX.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                performBounceAnimation();
            }
        });

        // Start the animation
        scaleDownX.start();
        scaleDownY.start();
    }

    //BounceAnimation
    private void performBounceAnimation() {
        // Create ObjectAnimator to smoothly animate scaleX and scaleY back to original values with a bounce effect
        ObjectAnimator bounceBackX = ObjectAnimator.ofFloat(slide_explore, "scaleX", originalScaleX);
        ObjectAnimator bounceBackY = ObjectAnimator.ofFloat(slide_explore, "scaleY", originalScaleY);

        // Set the duration of the animation
        int duration = 400;
        bounceBackX.setDuration(duration);
        bounceBackY.setDuration(duration);

        // Set a bounce interpolator for a realistic bouncing effect
        bounceBackX.setInterpolator(new BounceInterpolator());
        bounceBackY.setInterpolator(new BounceInterpolator());

        // Set up the AnimatorListener to reset the flag when bounce-back animation is complete
        bounceBackX.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                isAnimationInProgress = false;
            }
        });

        // Start the animation
        bounceBackX.start();
        bounceBackY.start();
    }
    @Override
    public void onDestroy() {
        super.onDestroy();
        // Set the flag to indicate that the fragment is no longer active
        isFragmentActive = false;
    }
}