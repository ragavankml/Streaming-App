package com.example.vertoxview.utils;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class FirebaseUtil {

    public static String currentUserId() {
        return FirebaseAuth.getInstance().getUid();
    }

    public static boolean isLoggedIn(){
        if(currentUserId()!=null){
            return true;
        }else {
            return false;
        }
    }
    public static DatabaseReference currentUserDetails() {
        // Assuming "users" is the root node in your Realtime Database
        return FirebaseDatabase.getInstance().getReference("users").child(currentUserId());
    }
}
