package com.example.vertoxview.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.vertoxview.R;
import com.example.vertoxview.model.UserModel;
import com.example.vertoxview.utils.FirebaseUtil;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;

import java.util.Objects;

public class LoginUserNameActivity extends AppCompatActivity {

    EditText usernameInput;
    AppCompatButton userLetIn;
    ProgressBar progressBar;
    String phoneNumber;
    UserModel userModel;
    boolean ne_or_no=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_user_name);

        //Full Screen
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
            getWindow().getAttributes().layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }

        usernameInput = findViewById(R.id.editText2);
        userLetIn = findViewById(R.id.save_user);
        progressBar = findViewById(R.id.progress_client);

        phoneNumber = Objects.requireNonNull(getIntent().getExtras()).getString("phone");
        getUserName();
        userLetIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ProgressS_H(true);
                setUserName();
            }
        });
    }

    void setUserName(){
        String username = usernameInput.getText().toString();
        if(username.isEmpty() || username.length()<3)
        {
            Toast.makeText(this, "User Name Must Contain 3 Characters", Toast.LENGTH_SHORT).show();
            ProgressS_H(false);
            return;
        }
        if (userModel!=null){
            userModel.setUsername(username);
        }else {
            userModel = new UserModel(phoneNumber,username);
        }
        FirebaseUtil.currentUserDetails().setValue(userModel).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful())
                {
                    String n_user = "new";
                    Intent intent = new Intent(LoginUserNameActivity.this,MainActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    if (!ne_or_no) {
                        intent.putExtra("new",n_user);
                    }
                    startActivity(intent);
                }
            }
        });
    }

    private void getUserName() {
        ProgressS_H(true);
        FirebaseUtil.currentUserDetails().get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {

                if (task.isSuccessful()){
                 userModel =  task.getResult().getValue(UserModel.class);
                 if (userModel!=null){
                     usernameInput.setText(userModel.getUsername());
                     ne_or_no = true;
                     ProgressS_H(false);
                 }
                 else {
                     ProgressS_H(false);
                 }
                }
            }
        });
    }

    public void ProgressS_H(boolean t){
        if (t){
            userLetIn.setVisibility(View.GONE);
            progressBar.setVisibility(View.VISIBLE);
        } else {
            userLetIn.setVisibility(View.VISIBLE);
            progressBar.setVisibility(View.GONE);
        }
    }

    @Override
    public void onBackPressed() {
            super.onBackPressed();
    }
}