package com.example.vertoxview.fragments;

import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.widget.AppCompatButton;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.BounceInterpolator;

import com.example.vertoxview.activity.LoginActivity;
import com.example.vertoxview.R;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ProfileLoginFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ProfileLoginFragment extends Fragment {

    private AppCompatButton loginBtn;
    private float originalScaleX;
    private float originalScaleY;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public ProfileLoginFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment ProfileLoginFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static ProfileLoginFragment newInstance(String param1, String param2) {
        ProfileLoginFragment fragment = new ProfileLoginFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_profile_login, container, false);

        // Initialize your button
        loginBtn = view.findViewById(R.id.login_btn);

        // Save the original scale values
        originalScaleX = loginBtn.getScaleX();
        originalScaleY = loginBtn.getScaleY();


        // Set touch listener for the button
        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), LoginActivity.class);

                // Optionally, you can pass data to the new activity using putExtra
                // intent.putExtra("key", "value");

                // Start the new activity
                startActivity(intent);
            }
        });

        loginBtn.setOnTouchListener(new View.OnTouchListener() {
            @SuppressLint("ClickableViewAccessibility")
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                // Check the action type (down, up, etc.)
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        // Call the function to perform size reduction animation
                        performSizeReductionAnimation();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        // Reset the scale when the touch is released or canceled
                        performBounceAnimation();
                        break;
                }

                // Return false to allow other touch events to be handled
                return false;
            }
        });

        return view;
    }

    private void performSizeReductionAnimation() {
        // Create ObjectAnimator to smoothly animate scaleX and scaleY
        ObjectAnimator scaleDownX = ObjectAnimator.ofFloat(loginBtn, "scaleX", 0.9f);
        ObjectAnimator scaleDownY = ObjectAnimator.ofFloat(loginBtn, "scaleY", 0.9f);

        // Set the duration of the animation
        int duration = 100;
        scaleDownX.setDuration(duration);
        scaleDownY.setDuration(duration);

        // Start the animation
        scaleDownX.start();
        scaleDownY.start();
    }

    private void performBounceAnimation() {
        // Create ObjectAnimator to smoothly animate scaleX and scaleY back to original values with a bounce effect
        ObjectAnimator bounceBackX = ObjectAnimator.ofFloat(loginBtn, "scaleX", originalScaleX);
        ObjectAnimator bounceBackY = ObjectAnimator.ofFloat(loginBtn, "scaleY", originalScaleY);

        // Set the duration of the animation
        int duration = 400;
        bounceBackX.setDuration(duration);
        bounceBackY.setDuration(duration);

        // Set a bounce interpolator for a realistic bouncing effect
        bounceBackX.setInterpolator(new BounceInterpolator());
        bounceBackY.setInterpolator(new BounceInterpolator());

        // Start the animation
        bounceBackX.start();
        bounceBackY.start();
    }
}