package com.example.vertoxview.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.vertoxview.R;

public class LoginActivity extends AppCompatActivity {

    ImageView back_btn;
    EditText editText;
    TextView countryCode;
    AppCompatButton otpButton;
    AppCompatButton clearButton;
    String enteredText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        //Full Screen
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
            getWindow().getAttributes().layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }

        editText = findViewById(R.id.editText);
        otpButton = findViewById(R.id.otp_v_next);
        clearButton = findViewById(R.id.number_clear);
        countryCode = findViewById(R.id.textView5);

        // Add a TextWatcher to the EditText
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                // Check if the EditText has exactly 10 digits and update the visibility of the button
                if (s != null && s.length() == 10) {
                    otpButton.setVisibility(View.VISIBLE);
                } else {
                    otpButton.setVisibility(View.GONE);
                }
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // Not used
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Not used
            }
        });

        // Add another TextWatcher to the EditText to handle the clear button visibility
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                // Check if the EditText has any text and update the visibility of the clear button
                clearButton.setVisibility(s != null && s.length() > 0 ? View.VISIBLE : View.GONE);
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // Not used
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Not used
            }
        });

        // Set an OnClickListener for the clear button to clear the text in the EditText
        clearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editText.getText().clear();
            }
        });

        //Otp To pass
        otpButton.setOnClickListener(v -> {
            enteredText = editText.getText().toString();
            Intent intent = new Intent(LoginActivity.this,otpActivity.class);
            intent.putExtra("phone",enteredText);
            startActivity(intent);
        });

        //Back btn
        back_btn = findViewById(R.id.btn_back);

        back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

    }
}