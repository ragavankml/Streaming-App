package com.example.vertoxview.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.vertoxview.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

public class otpActivity extends AppCompatActivity {

    private EditText otp_1, otp_2, otp_3, otp_4, otp_5, otp_6;
    // Otp Lly handeler
    private final Handler handler = new Handler();
    ImageView back_btn;
    Button verify_otp;
    ProgressBar progressBar;
    String phone_number,phone_number_wcountry;
    String sent_pn;
    TextView sent_phone_text,resend_text;
    FirebaseAuth mAuth = FirebaseAuth .getInstance();
    Long timeoutSeconds = 30L;
    String verification_code;
    LinearLayout opSend,opFailed;
    PhoneAuthProvider.ForceResendingToken ResendingToken;
    boolean otp_sendcheck = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp);
        //Full Screen
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
            getWindow().getAttributes().layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }

        // Initialize Firebase
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        phone_number= Objects.requireNonNull(getIntent().getExtras()).getString("phone");
        phone_number_wcountry = "+91"+phone_number;

        String userId = UUID.randomUUID().toString();
        // Now, you can use this generated user ID in your DatabaseReference

        sent_pn = "Enter OTP sent to +91 "+phone_number;

        otp_1 = findViewById(R.id.otp_1);
        otp_2 = findViewById(R.id.otp_2);
        otp_3 = findViewById(R.id.otp_3);
        otp_4 = findViewById(R.id.otp_4);
        otp_5 = findViewById(R.id.otp_5);
        otp_6 = findViewById(R.id.otp_6);

        progressBar = findViewById(R.id.progress_client);

        verify_otp = findViewById(R.id.otp_v_next_otp);
        verify_otp.setVisibility(View.GONE); // Initially hide the button

        resend_text = findViewById(R.id.textView3);

        sent_phone_text = findViewById(R.id.s_n_t);

        sent_phone_text.setText(sent_pn);

        opSend = findViewById(R.id.otp_send);
        opFailed = findViewById(R.id.otp_notsend);

        setupTextWatchers();

        //Back btn
        back_btn = findViewById(R.id.btn_back);

        back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        //Send Otp
        sendOtp(phone_number_wcountry,false);

        verify_otp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(otp_sendcheck) {
                    ProgressS_H(true);
                    String user_in_Code = otp_1.getText().toString() + otp_2.getText().toString() + otp_3.getText().toString() + otp_4.getText().toString() + otp_5.getText().toString() + otp_6.getText().toString();
                    PhoneAuthCredential credential = PhoneAuthProvider.getCredential(verification_code, user_in_Code);
                    signIn(credential);
                }
            }
        });

        resend_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ProgressS_H(true);
                sendOtp(phone_number_wcountry,true);
            }
        });

        // Hide opSend after 5 seconds
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                opSend.setVisibility(View.GONE);
            }
        }, 5000);
    }

    private void setupTextWatchers() {
        final EditText[] editTexts = {otp_1, otp_2, otp_3, otp_4, otp_5, otp_6};

        for (int i = 0; i < editTexts.length; i++) {
            final int currentIndex = i;

            editTexts[i].addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                    // Not needed for this example
                }

                @Override
                public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                    // Not needed for this example
                }

                @Override
                public void afterTextChanged(Editable editable) {
                    if (editable.length() == 1 && currentIndex < editTexts.length - 1) {
                        // Move focus to the next EditText
                        editTexts[currentIndex + 1].requestFocus();
                    } else if (editable.length() == 0 && currentIndex > 0) {
                        // Move to the previous EditText when backspace is pressed
                        editTexts[currentIndex - 1].requestFocus();
                    }

                    // Check if all fields are filled to show the button
                    boolean allFieldsFilled = true;
                    for (EditText editText : editTexts) {
                        if (editText.getText().length() != 1) {
                            allFieldsFilled = false;
                            break;
                        }
                    }

                    // Update the visibility of the verify_otp button
                    verify_otp.setVisibility(allFieldsFilled ? View.VISIBLE : View.GONE);
                }
            });

            editTexts[i].setOnKeyListener(new View.OnKeyListener() {
                @Override
                public boolean onKey(View view, int keyCode, KeyEvent keyEvent) {
                    if (keyCode == KeyEvent.KEYCODE_DEL
                            && keyEvent.getAction() == KeyEvent.ACTION_DOWN
                            && currentIndex > 0
                            && editTexts[currentIndex].getText().length() == 0) {
                        // Backspace pressed, move focus to the previous EditText
                        editTexts[currentIndex - 1].requestFocus();
                        return true; // consume the event
                    }
                    return false;
                }
            });
        }
    }

    void sendOtp(String phonenumber, boolean isResend){
        otp_sendcheck = false;
        progressBar.setVisibility(View.VISIBLE);
        PhoneAuthOptions.Builder builder =
                PhoneAuthOptions.newBuilder(mAuth)
                        .setPhoneNumber(phonenumber)
                        .setTimeout(timeoutSeconds, TimeUnit.SECONDS)
                        .setActivity(this)
                        .setCallbacks(new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                            @Override
                            public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
                                signIn(phoneAuthCredential);
                            }

                            @Override
                            public void onVerificationFailed(@NonNull FirebaseException e) {
                                //Start Time and after 5 second hide
                               startOTPSendTimer(false);
                               ProgressS_H(false);
                            }

                            @Override
                            public void onCodeSent(@NonNull String s, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                                super.onCodeSent(s, forceResendingToken);
                                verification_code=s;
                                otp_sendcheck=true;
                                ResendingToken = forceResendingToken;
                                startResendTimer();
                                ProgressS_H(false);
                                //Start Time and after 5 second hide
                                startOTPSendTimer(true);
                            }
                        });
        if(isResend){
            PhoneAuthProvider.verifyPhoneNumber(builder.setForceResendingToken(ResendingToken).build());
        }else {
            PhoneAuthProvider.verifyPhoneNumber(builder.build());
        }
    }


    void signIn(PhoneAuthCredential phoneAuthCredential){
        //Login and go to next Activity
        mAuth.signInWithCredential(phoneAuthCredential).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful())
                {
                    ProgressS_H(false);
                    Intent intent = new Intent(otpActivity.this,LoginUserNameActivity.class);
                    intent.putExtra("phone",phone_number_wcountry);
                    startActivity(intent);
                }else {
                    ProgressS_H(false);
                    Toast.makeText(otpActivity.this, "Wrong OTP", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void startResendTimer() {
        resend_text.setEnabled(false);

        new CountDownTimer(timeoutSeconds * 1000, 1000) {
            public void onTick(long millisUntilFinished) {
                resend_text.setText("Resend OTP in " + millisUntilFinished / 1000 + " seconds");
            }

            public void onFinish() {
                resend_text.setText("Resend OTP");
                resend_text.setEnabled(true);
            }
        }.start();
    }

    private void startOTPSendTimer(boolean i) {
        if (i)
        {
            opSend.setVisibility(View.VISIBLE);
        }else {
            opFailed.setVisibility(View.VISIBLE);
        }


        new CountDownTimer(5000, 1000) { // 5000 milliseconds, 1000 millisecond interval
            public void onTick(long millisUntilFinished) {
                // Do something during the countdown if needed
            }

            public void onFinish() {
                if (i)
                {
                    opSend.setVisibility(View.GONE);
                }else {
                    opFailed.setVisibility(View.GONE);
                }

            }
        }.start();
    }



    public void ProgressS_H(boolean t){
        if (t){
            verify_otp.setVisibility(View.GONE);
            progressBar.setVisibility(View.VISIBLE);
        } else {
            verify_otp.setVisibility(View.VISIBLE);
            progressBar.setVisibility(View.GONE);
        }

    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}