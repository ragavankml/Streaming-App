package com.example.vertoxview.model;

public class MostPopularAnimeModel {

    private String title;
    private String description;
    private String thumbnail;
    private String coverPhoto;
    private String videourl;
    private String First_ep_url;
    private String First_ep_title;
    private String NameUrl;

    public MostPopularAnimeModel(String title, String thumbnail, String coverPhoto,String description, String videoUrl,String firstepurl, String firepti, String nameurl) {
        this.title = title;
        this.thumbnail = thumbnail;
        this.coverPhoto = coverPhoto;
        this.description = description;
        this.videourl = videoUrl;
        this.First_ep_url = firstepurl;
        this.First_ep_title = firepti;
        this.NameUrl = nameurl;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public String getCoverPhoto() {
        return coverPhoto;
    }

    public void setCoverPhoto(String coverPhoto) {
        this.coverPhoto = coverPhoto;
    }

    public String getVideourl() {
        return videourl;
    }

    public void setVideourl(String videourl) {
        this.videourl = videourl;
    }

    public String getFirst_ep_url() {
        return First_ep_url;
    }

    public void setFirst_ep_url(String first_ep_url) {
        First_ep_url = first_ep_url;
    }

    public String getFirst_ep_title() {
        return First_ep_title;
    }

    public void setFirst_ep_title(String first_ep_title) {
        First_ep_title = first_ep_title;
    }

    public String getNameUrl() {
        return NameUrl;
    }

    public void setNameUrl(String nameUrl) {
        NameUrl = nameUrl;
    }
}
