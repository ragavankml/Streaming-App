package com.example.vertoxview.model;

public class SlideModel {

    private String Image;
    private String Title;
    private String Video;
    private String NameIm;
    private String First_ep_url;
    private String First_ep_title;

    public SlideModel(String image, String title, String video, String nameIm, String first_ep_url, String first_ep_title) {
        Image = image;
        Title = title;
        Video = video;
        NameIm = nameIm;
        First_ep_url = first_ep_url;
        First_ep_title= first_ep_title;
    }

    public String getImage() {
        return Image;
    }
    public String getTitle() {
        return Title;
    }
    public String getVideo(){
        return Video;
    }
    public String getNameIm(){
        return NameIm;
    }
    public String getFirst_ep_url() {
        return First_ep_url;
    }
    public String getFirst_ep_title() {
        return First_ep_title;
    }

    public void setImage(String image) {
        Image = image;
    }
    public void setTitle(String title) {
        Title = title;
    }
    public void  setVideo(String video){
        Video = video;
    }
    public void  setNameIm(String nameIm){
        Video = nameIm;
    }
    public void setFirst_ep_url(String first_ep_url) {
        First_ep_url = first_ep_url;
    }
    public void setFirst_ep_title(String first_ep_title) {
        First_ep_title = first_ep_title;
    }
}
