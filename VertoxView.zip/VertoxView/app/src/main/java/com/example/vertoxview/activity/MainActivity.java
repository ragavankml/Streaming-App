package com.example.vertoxview.activity;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.vertoxview.R;
import com.example.vertoxview.fragments.HomeFragment;
import com.example.vertoxview.fragments.NewFragment;
import com.example.vertoxview.fragments.ProfileFragment;
import com.example.vertoxview.fragments.ProfileLoginFragment;
import com.example.vertoxview.fragments.SearchFragment;
import com.example.vertoxview.utils.FirebaseUtil;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.snackbar.Snackbar;


public class MainActivity extends AppCompatActivity {
    BottomNavigationView bottomNavigationView;
    private static final long TIME_INTERVAL = 2000; // Time interval for double press in milliseconds
    private long backPressedTime;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Full Screen With Notch
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
            getWindow().getAttributes().layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        adjustLayoutForNavigationBar();




        // Check if New User
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("new")) {
             showWelcome();
        }


        //Id Finder
        bottomNavigationView = findViewById(R.id.bottom_nav);
        //Bottom Color
        bottomNavigationView.setItemIconTintList(null);

        //Default Fragment
        replaceFragment(new HomeFragment());

        //Bottom Navigation Click Function
        bottomNavigationView.setOnItemSelectedListener(item -> {

            int itemId = item.getItemId();
            if (itemId == R.id.navHome) {
                // Handle the Home menu item
                replaceFragment(new HomeFragment());
            } else if (itemId == R.id.navSearch) {
                // Handle the Search menu item
                replaceFragment(new SearchFragment());
            } else if (itemId == R.id.navNew) {
                // Handle the New menu item
                replaceFragment(new NewFragment());
            } else if (itemId == R.id.navProfile) {
                // Handle the Profile menu item
                if(FirebaseUtil.isLoggedIn()){
                    replaceFragment(new ProfileFragment());
                }
                else {
                    replaceFragment(new ProfileLoginFragment());
                }

            }

            return true;
        });

    }

    private void replaceFragment(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        // Replace the current fragment with the new one
        fragmentTransaction.replace(R.id.frame_Layout, fragment);

        // Commit the transaction
        fragmentTransaction.commit();
    }

    //Back Press Exit App
    @Override
    public void onBackPressed() {
        // If the back button is pressed within the time interval, exit the app
        if (backPressedTime + TIME_INTERVAL > System.currentTimeMillis()) {
            super.onBackPressed();
            finish(); // This will close the app
        } else {
           View view = findViewById(R.id.frame_Layout);
            Snackbar.make(view, "Press Back Again To exit App", 2000).show();
        }

        backPressedTime = System.currentTimeMillis();
    }

    private void adjustLayoutForNavigationBar() {
        View contentView = findViewById(android.R.id.content);
        contentView.setPadding(
                contentView.getPaddingLeft(),
                contentView.getPaddingTop(),
                contentView.getPaddingRight(),
                contentView.getPaddingBottom() + getNavigationBarHeight()
        );
    }

    private int getNavigationBarHeight() {
        Resources resources = getResources();
        int resourceId = resources.getIdentifier("navigation_bar_height", "dimen", "android");
        if (resourceId > 0) {
            return resources.getDimensionPixelSize(resourceId);
        }
        return 0;
    }


    //Show Welcome Alert
    private void showWelcome(){
        ConstraintLayout welcomeconstraintLayout  = findViewById(R.id.new_user);
        View view = LayoutInflater.from(MainActivity.this).inflate(R.layout.welcome_alert, welcomeconstraintLayout);
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setView(view);
        final AlertDialog alertDialog = builder.create();
        if(alertDialog.getWindow() != null)
        {
            alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        }
        alertDialog.show();
    }

}