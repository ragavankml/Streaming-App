package com.example.vertoxview.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.vertoxview.R;
import com.example.vertoxview.model.MostPopularAnimeModel;
import com.squareup.picasso.Picasso;
import java.util.List;

public class MostPopularAnimeAdapter extends RecyclerView.Adapter<MostPopularAnimeAdapter.MyViewHolder> {

    private Context context;
    private List<MostPopularAnimeModel> mData;
    private OnItemClickListener listener;
    private boolean isClickable = true;
    private static final long CLICK_DELAY = 1000; // 1 second delay

    public MostPopularAnimeAdapter(Context context, List<MostPopularAnimeModel> mData, OnItemClickListener listener) {
        this.context = context;
        this.mData = mData;
        this.listener = listener;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_card_slide, viewGroup, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, int i) {
        myViewHolder.bind(mData.get(i), listener);
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        private TextView TvTitle;
        private ImageView ImgMovie;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            TvTitle = itemView.findViewById(R.id.item_movie_title);
            ImgMovie = itemView.findViewById(R.id.item_movie_img);
        }

        public void bind(final MostPopularAnimeModel anime, final OnItemClickListener listener) {
            TvTitle.setText(anime.getTitle());
            // Use Picasso to load the image into the ImageView
            Picasso.get()
                    .load(anime.getThumbnail())
                    .into(ImgMovie);

            // Set an onClickListener for the item view
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (isClickable) {
                        isClickable = false;
                        listener.onItemClick(anime);
                        // Post a delayed runnable to reset the flag after a certain delay
                        v.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                isClickable = true;
                            }
                        }, CLICK_DELAY);
                    }
                }
            });
        }
    }

    // Interface for item click events
    public interface OnItemClickListener {
        void onItemClick(MostPopularAnimeModel anime);
    }
}
