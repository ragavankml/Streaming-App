package com.example.vertoxview.model;

public class EpisodeModel {

    String chname,name,url;

    EpisodeModel(){

    }

    public EpisodeModel(String chname, String name, String url) {
        this.chname = chname;
        this.name = name;
        this.url = url;
    }

    public String getChname() {
        return chname;
    }

    public String getName() {
        return name;
    }

    public String getUrl() {
        return url;
    }
}
