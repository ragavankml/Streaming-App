package com.example.vertoxview.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.vertoxview.R;

import java.util.List;

public class SubtitleTrackAdapter extends RecyclerView.Adapter<SubtitleTrackAdapter.ViewHolder> {

    private List<String> subtitleTracks;
    private OnItemClickListener clickListener;

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public SubtitleTrackAdapter(List<String> audioTracks, OnItemClickListener clickListener) {
        this.subtitleTracks = audioTracks;
        this.clickListener = clickListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_audio_track, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        String audioTrack = subtitleTracks.get(position);
        holder.audioTrackName.setText(audioTrack);

        // Set click listener on the item
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (clickListener != null) {
                    int adapterPosition = holder.getAdapterPosition();
                    if (adapterPosition != RecyclerView.NO_POSITION) {
                        clickListener.onItemClick(adapterPosition);
                    }
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return subtitleTracks.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView audioTrackName;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            audioTrackName = itemView.findViewById(R.id.audioTrackName);
        }
    }
}
