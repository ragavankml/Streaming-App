package com.example.vertoxview.activity;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;


import androidx.annotation.ColorInt;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.vertoxview.R;
import com.example.vertoxview.adapter.AudioTrackAdapter;
import com.example.vertoxview.adapter.EpisodeAdapter;
import com.example.vertoxview.adapter.SubtitleTrackAdapter;
import com.example.vertoxview.model.EpisodeModel;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.exoplayer2.C;
import com.google.android.exoplayer2.Format;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.source.DefaultMediaSourceFactory;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.source.TrackGroup;
import com.google.android.exoplayer2.source.TrackGroupArray;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.ui.AspectRatioFrameLayout;
import com.google.android.exoplayer2.ui.PlayerView;
import com.google.android.exoplayer2.util.MimeTypes;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/** @noinspection ALL*/
public class PlayActivity extends AppCompatActivity {

    private Handler handler;
    private Runnable updateColorRunnable;
    private TypedArray statusBarColors;
    private SimpleExoPlayer player;
    private PlayerView playerView;
    private RelativeLayout adaptiveBackgroundLayout;
    private static final String STATUS_BAR_COLOR_KEY = "status_bar_color";
    public  ImageView videoOrientationImageView,settingImageView;
    public  ConstraintLayout Orientation_Layout;
    public boolean  oriantation = false;
    public ConstraintLayout outher_content,setting_layout,setting_click_bg,track_layout,track_selector_layout,track_click_bg;
    public ConstraintLayout subtitle_selector_layout,subtitle_click_bg,subtitle_layout;
    public TextView Title_lan,Title_po;
    public TextView videoCurrentLanguageTextView,videoCurrentSubtitleTextView;
    //Minimum Video you want to buffer while Playing
    private int MIN_BUFFER_DURATION = 2000;
    //Max Video you want to buffer during PlayBack
    private int MAX_BUFFER_DURATION = 10000;
    //Min Video you want to buffer before start Playing it
    private int MIN_PLAYBACK_START_BUFFER = 1500;
    //Min video You want to buffer when user resumes video
    private int MIN_PLAYBACK_RESUME_BUFFER = 2000;
    private DefaultTrackSelector trackSelector;
    List<String> audioTracks = new ArrayList<>();
    ArrayList<String> subtitlesList = new ArrayList<>();
    // Define a flag to check if initialization has been done
    private boolean isInitialized = false;
    RecyclerView recyclerView;
    DatabaseReference database;
    EpisodeAdapter adapter;
    ArrayList<EpisodeModel> list;
    TextView viewMoreTitle;
    private boolean isExpanded = false;
    public ProgressBar progressBarBP;
    ImageView play_btn,pause_btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play);

        // Add the FLAG_KEEP_SCREEN_ON flag to keep the screen always active
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        Intent intent = getIntent();
        String data = intent.getStringExtra("FirtEpUrl");
        String data1 = intent.getStringExtra("FirtEpTitle");
        String title = intent.getStringExtra("Title_Onely");


        //Landscape Title
        Title_lan = findViewById(R.id.title_landscape);
        //Potrate Title
        Title_po = findViewById(R.id.episode_title);

        //Set the Ep Title in Bout TextView
        Title_lan.setText(data1);
        Title_po.setText(data1);
        viewMoreTitle = findViewById(R.id.view_more_title);

        //progressBarBP
        progressBarBP = findViewById(R.id.prBar);

        //Play And Pause
        play_btn  = findViewById(R.id.exo_play);
        pause_btn = findViewById(R.id.exo_pause);

        adaptiveBackgroundLayout = findViewById(R.id.gradientRel);

        //Outher content
        outher_content = findViewById(R.id.content_layout);

        //Setting Layout
        setting_layout = findViewById(R.id.setting_bottom);

        //Setting Click Background Layout
        setting_click_bg = findViewById(R.id.setting_click_bg);

        //Track Click Background Layout
        track_click_bg = findViewById(R.id.track_click_bg);

        // Initialize the CurrentLanguage
        videoCurrentLanguageTextView = findViewById(R.id.video_current_language);

        // Initialize the CurrentSubtitle
        videoCurrentSubtitleTextView = findViewById(R.id.video_current_subtitle);

        //Track Layout
        track_layout = findViewById(R.id.exo_audio_track);

        //Track Selector Layout
        track_selector_layout = findViewById(R.id.track_setector_bottom);

        //Subtitle Layout
        subtitle_layout = findViewById(R.id.exo_subtitle);

        //Subtitle Selector Layout
        subtitle_selector_layout = findViewById(R.id.subtitle_setector_bottom);

        //Subtitle Click Background Layout
        subtitle_click_bg = findViewById(R.id.subtitle_click_bg);

        // Create a DefaultTrackSelector with context
        trackSelector = new DefaultTrackSelector(this);
        // Initialize ExoPlayer
        player = new SimpleExoPlayer.Builder(this).setTrackSelector(trackSelector).build();

        // Initialize PlayerView
        playerView = findViewById(R.id.playerView);
        playerView.setPlayer(player);

        //Eepsiod RCV
        // Inside your activity
        recyclerView = findViewById(R.id.your_recycler_view_id);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        FirebaseRecyclerOptions<EpisodeModel> options =
                new FirebaseRecyclerOptions.Builder<EpisodeModel>().setQuery(FirebaseDatabase.getInstance().getReference().child(title),EpisodeModel.class)
                        .build();


        adapter = new EpisodeAdapter(options);
        recyclerView.setAdapter(adapter);

        // Set item click listener for the adapter
        adapter.setOnItemClickListener(new EpisodeAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(EpisodeModel episodeModel) {
                // Handle item click here, e.g., play the selected video
                String videoUrl = episodeModel.getUrl();
                String title = episodeModel.getChname();
                // Set the selected video URL to the ExoPlayer
                MediaItem mediaItem = MediaItem.fromUri(videoUrl);
                player.setMediaItem(mediaItem);
                player.setPlayWhenReady(true);
                isInitialized =  false;
                Title_lan.setText(title);
                Title_po.setText(title);

            }
        });

        viewMoreTitle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isExpanded = !isExpanded;
                updateVisibility();
            }
        });

        // Initialize the videoCurrentLanguageTextView
        videoCurrentLanguageTextView = findViewById(R.id.video_current_language);

        // Create a MediaItem with the video URL
        MediaItem mediaItem = MediaItem.fromUri(data);

        // Create a MediaSourceFactory
        DefaultMediaSourceFactory mediaSourceFactory = new DefaultMediaSourceFactory(this);

        // Create a MediaSource from the MediaItem
        MediaSource mediaSource = mediaSourceFactory.createMediaSource(mediaItem);

        // Set the MediaSource to the player
        player.setMediaSource(mediaSource);

        // Prepare the player
        player.prepare();

        // Start playing the video
        player.setPlayWhenReady(true);

        player.addListener(new Player.Listener() {
            @Override
            public void onIsPlayingChanged(boolean isPlaying) {
                Player.Listener.super.onIsPlayingChanged(isPlaying);
                if (isPlaying && !isInitialized) {
                    // The player is playing, update the current audio track
                    updateCurrentAudioTrack();

                    // Inside your onCreate() method
                    RecyclerView audioTrackRecyclerView = findViewById(R.id.trackes_rv);
                    RecyclerView subTitleRecyclerView = findViewById(R.id.subtitle_rv);
                    audioTrackRecyclerView.setLayoutManager(new LinearLayoutManager(PlayActivity.this));
                    subTitleRecyclerView.setLayoutManager(new LinearLayoutManager(PlayActivity.this));

                    // Use the getAudioTracks() method from the previous example
                    List<String> audioTracks = getAudioTracks();
                    // Use the getSubtitleTrack method from the previous example
                    List<String> subtitleLists = getSubtitleTrack();

                    // Create and set the adapter with item click listener
                    AudioTrackAdapter audioTrackAdapter = new AudioTrackAdapter(audioTracks, new AudioTrackAdapter.OnItemClickListener() {
                        @Override
                        public void onItemClick(int position) {
                            // Handle item click here
                            trackSelector.setParameters(trackSelector.buildUponParameters().setPreferredAudioLanguage(audioTracks.get(position)));
                            videoCurrentLanguageTextView.setText(audioTracks.get(position));
                            slideOutTrack(track_selector_layout);
                            //Snackbar
                            View rootView = findViewById(R.id.root_layout);
                            Snackbar.make(rootView, " Audio Changed To (" + audioTracks.get(position) + ") ", 500).show();
                        }
                    });

                    // Create and set the adapter with item click listener
                    SubtitleTrackAdapter subtitleTrackAdapter = new SubtitleTrackAdapter(subtitleLists, new SubtitleTrackAdapter.OnItemClickListener() {
                        @Override
                        public void onItemClick(int position) {
                            

                        }
                    });

                    subTitleRecyclerView.setAdapter(subtitleTrackAdapter);
                    audioTrackRecyclerView.setAdapter(audioTrackAdapter);

                    // Set the flag to true to indicate that initialization has been done
                    isInitialized = true;
                }
            }
        });

        // Set the initial status bar color to the saved color or black if not saved
        Window window = getWindow();
        int savedColor = getSavedStatusBarColor();
        window.setStatusBarColor(savedColor != -1 ? savedColor : Color.BLACK);

        // Load the colors from the color XML file
        statusBarColors = getResources().obtainTypedArray(R.array.status_bar_colors);

        //Color Change Runner
        handler = new Handler(Looper.getMainLooper());

        // Start a periodic task to update the status bar color every 5 seconds
        updateColorRunnable = new Runnable() {
            @Override
            public void run() {
                updateStatusBarColorRandomly();
                handler.postDelayed(this, 10000); // Repeat every 10 seconds
            }
        };
        handler.post(updateColorRunnable);

        //Play View Cotrol Id
        videoOrientationImageView = findViewById(R.id.video_orintation_icon);
        Orientation_Layout = findViewById(R.id.video_orintation);
        //Setting Id
        settingImageView = findViewById(R.id.setting_btn);
        // Set click listener for the video_orintation ImageView
        Orientation_Layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleFullScreen();
            }
        });
        //Setting Btn on Click
        settingImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    setting_layout.setVisibility(View.VISIBLE);
                    slideIn(setting_layout);
            }
        });

        //Subtitle Track Click
        subtitle_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                slideOut(setting_layout);
                slideInsubtitle(subtitle_selector_layout);
            }
        });

        //Subtitle Click Bg
        subtitle_click_bg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (subtitle_selector_layout.getVisibility() == View.VISIBLE) {
                    // If visible, hide it with sliding animation
                    slideOutsubtitle(subtitle_selector_layout);
                } else {
                    // If hidden, make it visible with sliding animation
                    subtitle_selector_layout.setVisibility(View.VISIBLE);
                    slideInsubtitle(subtitle_selector_layout);
                }
            }
        });

        //Audio Track Click
        track_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    slideOut(setting_layout);
                    slideInTrack(track_selector_layout);
            }
        });
        //Track Click Bg
        track_click_bg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (track_selector_layout.getVisibility() == View.VISIBLE) {
                    // If visible, hide it with sliding animation
                    slideOutTrack(track_selector_layout);
                } else {
                    // If hidden, make it visible with sliding animation
                    track_selector_layout.setVisibility(View.VISIBLE);
                    slideInTrack(track_selector_layout);
                }
            }
        });
        //Setting Click Bg
        setting_click_bg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (setting_layout.getVisibility() == View.VISIBLE) {
                    // If visible, hide it with sliding animation
                    slideOut(setting_layout);
                } else {
                    // If hidden, make it visible with sliding animation
                    setting_layout.setVisibility(View.VISIBLE);
                    slideIn(setting_layout);
                }
            }
        });

        // Show progress bar while preparing the player
        player.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int state) {
                switch (state) {
                    case Player.STATE_BUFFERING:
                    case Player.STATE_IDLE:
                        showProgressBar();
                        break;
                    case Player.STATE_READY:
                        hideProgressBar();
                        break;
                    case Player.STATE_ENDED:
                        // Handle video playback completion
                        break;
                }
            }
        });

    }

    //First Audio Track Insert
    private void updateCurrentAudioTrack() {
        //Audio Track
        ArrayList<String> audioTrack = new ArrayList<>();

        // Clear the old data
        audioTrack.clear();
        if (player.getCurrentTrackGroups().length > 0) {
            for (int i = 0; i < player.getCurrentTrackGroups().length; i++) {
                TrackGroup trackGroup = player.getCurrentTrackGroups().get(i);

                if (trackGroup.length > 0) {
                    Format format = trackGroup.getFormat(0);

                    // Check if the track is of audio type
                    if (MimeTypes.isAudio(format.sampleMimeType)) {
                        String language = new Locale(format.language).getDisplayLanguage();
                        audioTrack.add(language);
                    }
                }
            }
        } else {
            audioTrack.add("No Audio Track");
        }
        videoCurrentLanguageTextView.setText(audioTrack.get(0));
    }

    //First Subtitle Insert
    private ArrayList<String> getSubtitleTrack() {
        subtitlesList.clear();
        if (player.getCurrentTrackGroups().length > 0) {
            for (int groupIndex = 0; groupIndex < player.getCurrentTrackGroups().length; groupIndex++) {
                TrackGroupArray trackGroups = player.getCurrentTrackGroups();
                TrackGroup trackGroup = trackGroups.get(groupIndex);

                for (int i = 0; i < trackGroup.length; i++) {
                    Format format = trackGroup.getFormat(i);

                    // Check if the track is of type C.TRACK_TYPE_TEXT (subtitle)
                    if (MimeTypes.isText(format.sampleMimeType)) {
                        String language = format.language != null ? format.language : "und"; // "und" represents undetermined language
                        // Remove specified characters from format.label
                        String cleanedLabel = format.label != null ? format.label.replaceAll("[\\[\\]()]", "") : "";;
                        subtitlesList.add(
                                new Locale(language).getDisplayLanguage() +
                                        " ["+cleanedLabel+"]");
                    }
                }
            }
        }

        if (subtitlesList.isEmpty()) {
            subtitlesList.add("No Subtitle");
        }
        return subtitlesList;
    }



    private List<String> getAudioTracks() {
        // Populate the list of audio tracks based on your player instance
        // You can modify this method to get audio tracks from your ExoPlayer instance
        // Clear the old data
        audioTracks.clear();
        if (player.getCurrentTrackGroups().length > 0) {
            for (int i = 0; i < player.getCurrentTrackGroups().length; i++) {
                TrackGroup trackGroup = player.getCurrentTrackGroups().get(i);

                if (trackGroup.length > 0) {
                    Format format = trackGroup.getFormat(0);

                    // Check if the track is of audio type
                    if (MimeTypes.isAudio(format.sampleMimeType)) {
                        String language = new Locale(format.language).getDisplayLanguage();
                        audioTracks.add(language);
                    }
                }
            }
        } else {
            audioTracks.add("No Audio Track");
        }

        return audioTracks;
    }


    // Function to slide out the view (hide with animation)
    private void slideOut(View view) {
        view.animate()
                .translationY(view.getHeight())
                .alpha(0.0f)
                .setDuration(200)
                .withEndAction(() -> view.setVisibility(View.INVISIBLE))
                .start();
        setting_click_bg.setVisibility(View.GONE);
    }

    // Function to slide in the view (show with animation)
    private void slideIn(View view) {
        setting_click_bg.setVisibility(View.VISIBLE);
        view.setVisibility(View.VISIBLE);
        view.setAlpha(0.0f);
        view.animate()
                .translationY(0)
                .alpha(1.0f)
                .setDuration(200)
                .start();
    }
    // Function to slide out the view (hide with animation)
    private void slideOutTrack(View view) {
        view.animate()
                .translationY(view.getHeight())
                .alpha(0.0f)
                .setDuration(200)
                .withEndAction(() -> view.setVisibility(View.INVISIBLE))
                .start();
        track_click_bg.setVisibility(View.GONE);
    }

    // Function to slide in the view (show with animation)
    private void slideInTrack(View view) {
        track_click_bg.setVisibility(View.VISIBLE);
        view.setVisibility(View.VISIBLE);
        view.setAlpha(0.0f);
        view.animate()
                .translationY(0)
                .alpha(1.0f)
                .setDuration(200)
                .start();
    }

    // Function to slide out the view (hide with animation)
    private void slideOutsubtitle(View view) {
        view.animate()
                .translationY(view.getHeight())
                .alpha(0.0f)
                .setDuration(200)
                .withEndAction(() -> view.setVisibility(View.INVISIBLE))
                .start();
        subtitle_click_bg.setVisibility(View.GONE);
    }

    // Function to slide in the view (show with animation)
    private void slideInsubtitle(View view) {
        subtitle_click_bg.setVisibility(View.VISIBLE);
        view.setVisibility(View.VISIBLE);
        view.setAlpha(0.0f);
        view.animate()
                .translationY(0)
                .alpha(1.0f)
                .setDuration(200)
                .start();
    }

    private void toggleFullScreen() {
        if (oriantation) {
            // Transition to portrait mode
            animateToPortrait();
        } else {
            // Transition to landscape mode
            animateToLandscape();
        }
    }

    private void updateStatusBarColorRandomly() {
        // Get a random color from the color XML file
        @ColorInt int randomColor = getRandomColor();

        // Smoothly transition to the new status bar color
        smoothTransitionToColor(randomColor);

        // Set the background color of the PlayerView
        smoothTransitionToPlayerViewColor(randomColor);

        // Update the color of the adaptive background
        updateAdaptiveBackgroundColor(randomColor);
    }

    private void updateAdaptiveBackgroundColor(@ColorInt int newColor) {
        // Get the current background color
        GradientDrawable currentDrawable = (GradientDrawable) adaptiveBackgroundLayout.getBackground();
        int currentColor = currentDrawable.getColors()[0]; // Assuming you're using a two-color gradient

        // Create a ValueAnimator to smoothly interpolate between the current color and the new color
        ValueAnimator colorAnimator = ValueAnimator.ofObject(new ArgbEvaluator(), currentColor, newColor);
        colorAnimator.setDuration(5000); // Adjust the duration as needed
        colorAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animator) {
                int[] animatedColors = {
                        (int) animator.getAnimatedValue(),
                        Color.TRANSPARENT
                };
                currentDrawable.setColors(animatedColors);
                adaptiveBackgroundLayout.setBackground(currentDrawable);
            }
        });
        colorAnimator.start();
    }

    private void smoothTransitionToPlayerViewColor(@ColorInt int newColor) {
        // Get the current background color
        GradientDrawable currentDrawable = (GradientDrawable) playerView.getBackground();
        int currentColor = currentDrawable.getColors()[0]; // Assuming you're using a two-color gradient

        // Create a ValueAnimator to smoothly interpolate between the current color and the new color
        ValueAnimator colorAnimator = ValueAnimator.ofObject(new ArgbEvaluator(), currentColor, newColor);
        colorAnimator.setDuration(5000); // Adjust the duration as needed
        colorAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animator) {
                int[] animatedColors = {
                        (int) animator.getAnimatedValue(),
                        Color.TRANSPARENT
                };
                currentDrawable.setColors(animatedColors);
                playerView.setBackground(currentDrawable);
            }
        });
        colorAnimator.start();
    }


    private void smoothTransitionToColor(@ColorInt int newColor) {
        Window window = getWindow();
        int currentColor = window.getStatusBarColor();

        // Create a ValueAnimator to smoothly interpolate between the current color and the new color
        ValueAnimator colorAnimator = ValueAnimator.ofObject(new ArgbEvaluator(), currentColor, newColor);
        colorAnimator.setDuration(5000); // Adjust the duration as needed
        colorAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animator) {
                int animatedColor = (int) animator.getAnimatedValue();
                window.setStatusBarColor(animatedColor);
            }
        });
        colorAnimator.start();
    }

    private int getRandomColor() {
        int randomIndex = new Random().nextInt(statusBarColors.length());
        return statusBarColors.getColor(randomIndex, Color.BLACK);
    }

    private int getSavedStatusBarColor() {
        // Retrieve the saved status bar color from SharedPreferences
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        return preferences.getInt(STATUS_BAR_COLOR_KEY, -1);
    }

    private void saveStatusBarColor(int color) {
        // Save the status bar color to SharedPreferences
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt(STATUS_BAR_COLOR_KEY, color);
        editor.apply();
    }

    @Override
    protected void onStop() {
        super.onStop();
        // Pause the player when the app is minimized or closed
        if (player != null) {
            player.setPlayWhenReady(false);
        }
    }

    @Override
    protected void onDestroy() {
        // Save the current status bar color to be used when the activity is restarted
        Window window = getWindow();
        int currentColor = window.getStatusBarColor();
        saveStatusBarColor(currentColor);

        // Remove the updateColorRunnable to stop the periodic task when the activity is destroyed
        handler.removeCallbacks(updateColorRunnable);

        // Release the player to free up resources
        if (player != null) {
            player.release();
        }

        // Recycle the TypedArray to avoid memory leaks
        statusBarColors.recycle();
        adapter.stopListening();
        finish();
        super.onDestroy();
    }

    private void animateToPortrait() {
        // Clear FLAG_FULLSCREEN and FLAG_LAYOUT_NO_LIMITS flags
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
            getWindow().getAttributes().layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT;
            View decorView = getWindow().getDecorView();
            int uiOptions = View.SYSTEM_UI_FLAG_VISIBLE;
            decorView.setSystemUiVisibility(uiOptions);
        }

        oriantation = false;
        outher_content.setVisibility(View.VISIBLE);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        //Player Mode
        playerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FILL);
        player.setVideoScalingMode(C.VIDEO_SCALING_MODE_DEFAULT);

        // Animate the player view height change
        animatePlayerViewHeight(getResources().getDimensionPixelSize(R.dimen.player_view_height));
        Title_lan.setVisibility(View.GONE);
        videoOrientationImageView.setImageResource(R.drawable.exo_fullscreen);
    }

    private void animateToLandscape() {
        // Set FLAG_FULLSCREEN and FLAG_LAYOUT_NO_LIMITS flags
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
            getWindow().getAttributes().layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            View decorView = getWindow().getDecorView();
            int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
            decorView.setSystemUiVisibility(uiOptions);
        }

        oriantation = true;
        outher_content.setVisibility(View.GONE);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

        //Player Mode
        playerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        player.setVideoScalingMode(C.VIDEO_SCALING_MODE_DEFAULT);

        // Animate the player view height change
        animatePlayerViewHeight(ViewGroup.LayoutParams.MATCH_PARENT);
        Title_lan.setVisibility(View.VISIBLE);
        videoOrientationImageView.setImageResource(R.drawable.exo_smallscreen);
    }

    private void animatePlayerViewHeight(final int targetHeight) {
        final ViewGroup.LayoutParams layoutParams = playerView.getLayoutParams();
        final int startHeight = layoutParams.height;

        ValueAnimator animator = ValueAnimator.ofInt(startHeight, targetHeight);
        animator.setDuration(500); // Adjust the duration as needed
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                layoutParams.height = (int) animation.getAnimatedValue();
                playerView.setLayoutParams(layoutParams);
            }
        });
        animator.start();
    }

    private void updateVisibility() {
        TextView episodeTitle = findViewById(R.id.episode_title);

        if (isExpanded) {
            episodeTitle.setMaxLines(Integer.MAX_VALUE);
            viewMoreTitle.setText("View less...");
        } else {
            episodeTitle.setMaxLines(2);
            viewMoreTitle.setText("View more...");
        }
    }

    private void showProgressBar() {
        if (progressBarBP != null) {
            progressBarBP.setVisibility(View.VISIBLE);
        }
    }

    private void hideProgressBar() {
        if (progressBarBP != null) {
            progressBarBP.setVisibility(View.GONE);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }


}
